import { blankBgOpen, blankBgClose} from "./helper";

class Header{
    constructor(){
        // if(document.querySelector('.first-load')){
        //     document.querySelector('.first-load').remove();
        // }
        this.init();
    }

    stickyHeader = () => {
        window.onscroll = () => {
            if (document.body.scrollTop > 145 || document.documentElement.scrollTop > 145 ) {
                document.querySelector("#shopify-section-header").classList.add('sticky');                
            }
            else{
                document.querySelector("#shopify-section-header").classList.remove('sticky');
            }
        }

    }
    // stickyPromo = () => {
    //     window.onscroll = () => {
    //         if (document.body.scrollTop > 145 || document.documentElement.scrollTop > 145 ) {
    //             document.querySelector("#shopify-section-announcement-bar").classList.add('sticky');                 
    //         }
    //         else{
    //             document.querySelector("#shopify-section-announcement-bar").classList.remove('sticky');
    //         }
    //     }
    // }

    init = () => {
        this.stickyHeader();
        this.stickyPromo();
    }
}

new Header;