// console.log('hello there search section!');
blankBgOpen = () => {
    document.querySelector('.black-bg').classList.add('active');
    document.querySelector('body').classList.add('overflow-hidden');
  };
blankBgClose = () => {
    document.querySelector('.black-bg').classList.remove('active');
    document.querySelector('body').classList.remove('overflow-hidden');
  };
  blankBgtoggle = () => {
    document.querySelector('.black-bg').classList.toggle('active');
    document.querySelector('body').classList.toggle('overflow-hidden');
  };
  clearEvent = () => {
    document.querySelector(".search__input").addEventListener("input",(e)=>{
        if(e.target.value === ""){
            document.querySelector('.search-result').style.display = 'none';
        }
        else if(e.target.value !== ""){
            document.querySelector('.search-result').style.display = 'block';
        }
        else{
            searchProduct(e);
        }
    });
}
closeSearch = () => {
    // document.querySelector("#side_cart").classList.remove("active");
    searchClose();
    blankBgClose();
}

searchOpen = () => {
    document.querySelector(".quick-search").classList.toggle("search_popup_open");
    // console.log('open');
}

searchClose = () => {
    document.querySelector(".quick-search").classList.remove("search_popup_open");
    // console.log('close');
    // blankBgClose();
}

toggleDropdown = () => {
    document.querySelector(".search-icon-btn").addEventListener("click", (e) => {
        searchOpen();
        blankBgtoggle();
        
    });
    document.querySelector(".close-form").addEventListener("click", (e) => {
        document.querySelector(".quick-search-form").reset();
        document.querySelector('.search-result').style.display = 'none';
        searchClose();
        blankBgClose();
    });
}

inputEvents = () => {
    document.querySelector(".search__input").addEventListener("input",(e)=>{
        if(e.target.value === ""){
            let search_data = document.querySelector('.search-data');
            search_data.innerHTML = '';
            document.querySelector('.search-bottom').style.display = 'none';
        }
        else{
            searchProduct(e);
        }
    });
}

searchProduct = async (e) => {
    let query = '';
    query = e.target.value;
    await fetch(`/search/suggest.json?q=${query}&resources[type]=product&resources[limit]=10&resources[options][unavailable_products]=last`)
    .then(response => response.json())
    .then(suggestions => {
      const productSuggestions = suggestions.resources.results.products;
        
        if (productSuggestions.length === 0) {
        // var firstProductSuggestion = productSuggestions[0];
            resultNotFound(query);
        }
        else{ 
            resultFound(productSuggestions);
        }
    });
    // console.log(query);
}

searchForm = () => {
    if(document.querySelector('body').classList.contains('template-search')){
        console.log("search page is not working");

        console.log('hi');
        let search_terms = document.querySelector('.search-form-control').value;
        
        if( search_terms.length > 0 ){
            const scriptURL = 'https://script.google.com/macros/s/AKfycbxGXY7RcGnxo6ONucbM5fOoItqaRDtVGtLqHVmu7V9dov-Ej2SLrF-i3wjm0DigmkC8/exec'
            const form = document.forms['search-page-form']
            
            fetch(scriptURL, { method: 'POST', body: new FormData(form)})
            .then()
            .catch(error => console.error('Error!', error.message))
            
        }
    }

}

resultNotFound = (query) => {
    console.log('not found');
    let search_data = document.querySelector('.search-data');
    search_data.innerHTML = '';
    let search_bottom_html = `<span class="result-count">No Result Found</span>`;
    let search_bottom = document.querySelector('.search-bottom');
    search_bottom.innerHTML = search_bottom_html;
}

clickEvents = () => {
    document.querySelector(".black-bg").addEventListener("click", () => {
        closeSearch();
    });
    let elementss = document.querySelectorAll(".search-product");
    elementss.forEach((item, i) => {
        item.addEventListener("click", (e) => {
            let that = e.currentTarget;
            // console.log(that);
            searchFormEvent(that);
        });
    })
}

resultFound = (productSuggestions) => {
    // console.log(productSuggestions);
    let search_data = document.querySelector('.search-data');
    search_data.innerHTML = '';
    let str = '';
    productSuggestions.forEach((item, index) => {
        let itemImage = item.image;
        let itemName = item.title;
        let itemPrice = item.price;
        let itemUrl = item.url;
        // str = `<div class="search-product d-row  m-0">
        //                 <div class="col-lg-2 col-md-3 col-sm-4 col-4">
        //                     <a href="${itemUrl}" class="pre-search-url" >
        //                         <img src="${itemImage}" alt="item-img" class="search-image" >
        //                     </a>
        //                 </div>
        //                 <div class="col-lg-10 col-md-9 col-sm-7 col-7">
        //                     <a href="${itemUrl}">
        //                         <p>${itemName}</p>
        //                     </a>
        //                     <p class="price">${itemPrice}</p>
        //                 </div>
        //             </div>`;

        // search_data.innerHTML += str;
        str = `<div class="col-lg-2 col-md-3 col-sm-4 col-6 search_product_data">
                    <div class="search_product_img">
                        <a href="${itemUrl}" class="pre-search-url" >
                            <img src="${itemImage}" alt="item-img" class="search-image" >
                        </a>
                    </div>
                    <div class="search_product_details">
                        <a href="${itemUrl}">
                            <p>${itemName}</p>
                        </a>
               
                    </div>
                </div>`;

        search_data.innerHTML += str;

    });
    // <p class="price">₹${itemPrice}</p>
    let result_length = productSuggestions.length;
    let search_bottom_html = `<span class="result-msg">View All Result</span>`;
    let search_bottom = document.querySelector('.search-bottom');
    search_bottom.style.display = 'block';
    search_bottom.innerHTML = search_bottom_html;

    document.querySelector(".result-msg").addEventListener("click", (e) => {
        // console.log('click');
        document.querySelector(".quick-search-form").submit();

    });

    clickEvents();
}

searchFormEvent = (that) => {
    // console.log(that);
    let product_url_elem = that.querySelector('.pre-search-url');
    let product_url = product_url_elem.getAttribute('href');
    let pre_search_query = document.querySelector('.search__input').value;
    // console.log(pre_search_query);

    let pre_search_q = document.querySelector('.pre-search-form-query');
    let pre_search_url = document.querySelector('.pre-search-form-url');
    pre_search_q.value = pre_search_query;
    pre_search_url.value = product_url;
    

    // if( pre_search_q.length > 0 ){
        const scriptLINK = 'https://script.google.com/macros/s/AKfycbwMvxnG6_SYa8V-adALJRYxNMF21lXgLALquakbZkfJePoNSk_oEnWZkI6FCgCq91MU/exec'
        const pre_form = document.forms['pre-search-form']
        
        fetch(scriptLINK, { method: 'POST', body: new FormData(pre_form)})
        .then(response => alert("Thanks for Contacting us..! We Will Contact You Soon..."))
        .catch(error => console.error('Error!', error.message))
        
    // }
}

// clearEvent = () => {
//     // let clearEvent = document.querySelector('.search-icon-btn');
//     if(search__input == ''){
//         document.querySelector('.search-data').style.display = 'none';
//     }
// }


// searchBar = () => {
//     let searchBar = document.querySelector(".search-icon-btn");
    

//     }


clearEvent();
searchForm();
inputEvents();
toggleDropdown();
clickEvents();

// console.log('search form is over!');