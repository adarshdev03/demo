class CollectionPage{


}





if(document.querySelector('body').classList.contains('template-collection')){
    clickEvent = () =>{
        clickEvent();
        openfilter_loder();
    }
    
    
    openfilter_loder = () => {
        document.querySelector('.filter_loder').classList.add('active');
    }
    
    closefilter_loder = ()=>{
        document.querySelector('.filter_loder').classList.remove('active');
    }
    
    const formatMoney = (t) => {
        let e = custom.moneyFormat;
          function o(t, e) {
              return void 0 === t ? e : t
          }
          function i(t, e, i, r) {
              if (e = o(e, 2),
                  i = o(i, ","),
                  r = o(r, "."),
                  isNaN(t) || null == t)
                  return 0;
              t = (t / 100).toFixed(e);
              var n = t.split(".");
              return n[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1" + i) + (n[1] ? r + n[1] : "")
          }
          "string" == typeof t && (t = t.replace(".", ""));
          var r = ""
              , n = /\{\{\s*(\w+)\s*\}\}/
              , a = e || "${{amount}}";
          switch (a.match(n)[1]) {
              case "amount":
                  r = i(t, 2);
                  break;
              case "amount_no_decimals":
                  r = i(t, 0);
                  break;
              case "amount_with_comma_separator":
                  r = i(t, 2, ".", ",");
                  break;
              case "amount_with_space_separator":
                  r = i(t, 2, " ", ",");
                  break;
              case "amount_with_period_and_space_separator": 
                  r = i(t, 2, " ", ".");
                  break;
              case "amount_no_decimals_with_comma_separator":
                  r = i(t, 0, ".", ",");
                  break;
              case "amount_no_decimals_with_space_separator":
                  r = i(t, 0, " ");
                  break;
              case "amount_with_apostrophe_separator":
                  r = i(t, 2, "'", ".")
          }
          return a.replace(n, r)
    }
    
    collectionInput = (thisElem) => {
        let parent = thisElem.parentElement;
        // console.log("parent",parent);
        if(thisElem.checked){
            parent.classList.add("active_filter");
        }
        else {
            parent.classList.remove("active_filter");
        }
        collFilterInit(thisElem);
    }
    
    collFilterInit = (thisElem) => {
        let active_collection = document.querySelectorAll(".active_filter").firstElementChild; 
        let active_coll_link = thisElem.getAttribute('data-value');
        // console.log(active_coll_link);
        // console.log('thisElem',thisElem);
        let form_url_id = '';
        let coll_all = '/all-category'; 
        let shopurl = document.querySelector('.all_category_section').getAttribute('data-url');
        // console.log(shopurl);
        if(window.location.href.indexOf(coll_all) > -1){
            form_url_id = shopurl + '/' + 'collections/' + active_coll_link;
        }else{
            form_url_id = shopurl + '/' + 'collections/' + active_coll_link;
        }
    
        // console.log(form_url_id);
    
        window.history.pushState({form_url_id}, null, form_url_id);
        // let fil_link = document.getElementById('cate_pg');
        // console.log("call");
        
    
        filterInit(form_url_id,false);
    }
    
    checkinput = (thisElem,flag) => {
    
        // console.log('hello',thisElem)
        let parent = thisElem.parentElement;
        if(thisElem.checked){
            parent.classList.add("active_filter");
        }
        else {
            parent.classList.remove("active_filter");
        }
        findActiveFilter(thisElem,true,false);
        // this.sort_filter(thisElem,true,false);
    }
    
    setSelected = () => {
    
        let optionSections = document.getElementsByClassName("custom-opion");
        for( let i = 0; i < optionSections.length; i++ ){
            let sliders = optionSections[i].getAttribute("value");
            // console.log("slidersindex",sliders);
    
            let url = window.location.href;
            let active_sort_add = url.split('sort_by=');
            active_sort_add[1];
    
            if ( sliders == active_sort_add[1] ) {
                document.getElementById('sort-by').getElementsByTagName('option')[i].selected = 'selected';
                // console.log('sort_true');
            }
            else{
                // console.log('sort_active_false');
            }
    
        }
    }
    
    filterInit = async (form_url_id,flag) => {
        let url = '';
        if(flag == true){
            url = `${form_url_id}`;
        }
        else {
            url = `${form_url_id}?view=filter`;
        }
        // console.log(url);
        // console.log(form_url_id);
        let currentFilter = await fetch(url);
        if(currentFilter.ok){
            currentFilter = await currentFilter.text();
            // console.log(currentFilter);
            if (document.querySelector(".all_category_section")){
                document.querySelector(".all_category_section").innerHTML = "";
                let divContent = document.createElement("div");
                let parser = new DOMParser();
                let filterPage = parser.parseFromString(currentFilter, 'text/html');
                // console.log(filterPage);
                filterPage = filterPage.body.innerHTML;
                divContent.innerHTML = filterPage;
                // console.log(divContent);
                let innerHt = divContent.querySelector('.all_category_section').innerHTML;
                document.querySelector(".all_category_section").innerHTML = innerHt;
    
                setSelected();
            }
        }
        // this.slider();
        addFilterUrl();
        changeEvent();
        clickEvent();
        // this.stickyFilter();
        inputEvent();
        clickEvent();
    }
    
    findActiveFilter =  (thisElem,flag,flag2) => {
    
        // console.log("sfdcxasVDXZd",flag,flag2,thisElem);
        let shopurl = document.querySelector('.all_category_section').getAttribute('data-url');
        let collurl = document.querySelector('.category-section-wrap').getAttribute('data-collurl');
    
        let coll_all = '/all';  
        let activeFilter = [];
        let form_url_id = '';
        let active_tag_url = ''; 
        let sortFilters = [];
        // let activeTags = [];
    
        let fil_link = document.getElementById('cate_pg');
        let URL_links = fil_link.getAttribute("data-sort"); 
        // console.log(URL_links);
        let filter_data = fil_link.getAttribute("data-filter");
    
        // start
    
        let active_filters_temp = document.querySelectorAll(".active_sort_filter");
        if(active_filters_temp.length > 0){
            active_filters_temp.forEach((elem,i)=>{
                let filter_link = elem.getAttribute('data-link');
                // console.log(filter_link);
                // sortFilters = [filter_link];
                sortFilters= [filter_link];
                // console.log("sortFilters_active",sortFilters);
            })
        }
    
        // end
    
        if(flag2 != true){
    
            if(flag != true){
                activeFilter.push(thisElem);
                // console.log("thisElem",thisElem);
            }
            else{
                let current_filter = thisElem.getAttribute('data-val');
                // console.log(current_filter,"flag2");
            }
        }
        else {
            active_tag_url = thisElem;
            // console.log("active_tag_url",active_tag_url);
        }
        
    
        let active_filters = document.querySelectorAll(".active_filter");
        if(active_filters.length > 0){
            active_filters.forEach((elem,i)=>{
                
                let filter_param_name = elem.children[0];
                let filter_link = filter_param_name.getAttribute('data-link');
                // console.log(filter_link);
                activeFilter.push(filter_link);
            })
        }
        
        if(flag2 == true) {
            if(window.location.href.indexOf(coll_all) > -1){
                form_url_id = collurl + '/' + active_tag_url +'?' + activeFilter.join('&');
                // console.log(form_url_id,"sort url1");
            }else{
                form_url_id = collurl + '/' + active_tag_url + '/?'+ activeFilter.join('&');
                // console.log(form_url_id,"sort url2");
            }
        }
        else{
            if(window.location.href.indexOf(coll_all) > -1){
                form_url_id = collurl+ '/?'+ activeFilter.join('&') +'&'+ URL_links;
            }else{
                form_url_id = collurl+ '/?'+ activeFilter.join('&') +'&'+ URL_links;
                // form_url_id = collurl+ '/?'+ activeFilter.join('&') +'&'+ URL_link;
            }   
        }
           
    
        if(window.location.href.indexOf(coll_all) > -1){
            // form_url_id = collurl +'/?' + activeFilter.join('&');
            // form_url_id = collurl+ '/?'+ sortFilters.join('&')+'&'+ activeFilter.join('&');
            form_url_id = collurl+ '/?'+ activeFilter.join('&') +'&'+ URL_links;
            // console.log(form_url_id,"sort url3");
        }else{
            // form_url_id = collurl+ '/?'+ sortFilters.join('&')+'&'+ activeFilter.join('&');
            form_url_id = collurl+ '/?'+ activeFilter.join('&') +'&'+ URL_links;
            // console.log(sortFilters,"sortFilters");
        }
            
        
        
        window.history.pushState({form_url_id}, null, form_url_id);
        fil_link.getAttributeNode("data-filter").value = activeFilter;
        // console.log(fil_link);
        filterInit(form_url_id,true);
        addFilterUrl(form_url_id);
    
    }
    
    //if null = add --or-- not
    
    changeEvent = () => {
    
        let collBtn = document.querySelectorAll(".collection-filter");
        let last;
        if(collBtn.length > 0){
            collBtn.forEach((item,i)=>{
                item.addEventListener("change",(e)=>{
                    let that = e.currentTarget;
                    collectionInput(that);
                    if(last){
                        last.checked=false;
                    }
                    e.target.checked=true;
                    last=e.target;
                });
            })
            // console.log(collBtn);
        }
    
        let addBtns = document.querySelectorAll(".custom-checkbox-input");
        if(addBtns.length > 0){
            addBtns.forEach((item,i)=>{
                item.addEventListener("change",(e)=>{
                    let that = e.currentTarget;
                    checkinput(that);
                    getVals();
                    openfilter_loder();
                    // console.log("hello");
                });
            })
        }
    
        let tagBtns = document.querySelectorAll(".tag-input");
        if(tagBtns.length > 0){
            tagBtns.forEach((item,i)=>{
                item.addEventListener("change",(e)=>{
                    let thisItem = e.currentTarget;
                    checkTag(thisItem);
                    getVals();
                });
            })
        }
    
        // price range slider
        let sliderSections = document.getElementsByClassName("range-slider");
        for( let i = 0; i < sliderSections.length; i++ ){
            let sliders = sliderSections[i].getElementsByTagName("input");
            for( let j = 0; j < sliders.length; j++ ){
                if( sliders[j].type ==="range" ){
                    sliders[j].onchange = getVals;
                }
            }
        }
    
    }
    
    inputEvent = () => {
        document.querySelector("#price-range-min").addEventListener('input', (e) => {
            rangeInputListen();
        })
    
        document.querySelector("#price-range-max").addEventListener('input', (e) => {
            rangeInputListen();
        })
        
    }
    
    rangeInputListen = () => {
        let slides = document.querySelectorAll(".pricerange");
        let slide1_val = parseFloat( slides[0].value);
        let slide2_val = parseFloat( slides[1].value );
        let slide1 = ( slides[0]);
        let slide2 = ( slides[1]);
    
        if( slide1 > slide2 ){ 
            let tmp = slide2; slide2 = slide1; slide1 = tmp; 
        }
        if( slide1_val > slide2_val ){
            let tmp = slide2_val; 
            slide2_val = slide1_val; 
            slide1_val = tmp; 
        }
    
        // console.log( slide1_val + "-" + slide2_val);
        let rangeValues = document.querySelector('.rangeValues');
        let current_value = formatMoney(slide1_val*100) + "-" + formatMoney(slide2_val*100);
    
        rangeValues.textContent = current_value;
    
    }
    
    getVals = () => {
        let slides = document.querySelectorAll(".pricerange");
        let slide1_val = parseFloat( slides[0].value);
        let slide2_val = parseFloat( slides[1].value );
        let slide1 = ( slides[0]);
        let slide2 = ( slides[1]);
        // Neither slider will clip the other, so make sure we determine which is larger
        if( slide1 > slide2 ){ 
            let tmp = slide2; slide2 = slide1; slide1 = tmp; 
        }
        if( slide1_val > slide2_val ){
            let tmp = slide2_val; 
            slide2_val = slide1_val; 
            slide1_val = tmp; 
        }
    
        let parent = slides.parentElement;
    
        slide1.value=slide1_val;
        slide2.value=slide2_val;
    
        let slide1Gte = slide1.getAttribute('data-link');
        let slide2Lte = slide2.getAttribute('data-link');
        
        let slide1Url = slide1Gte+'='+slide1_val;
        let slide2Url = slide2Lte+'='+slide2_val;
    
        let finalUrl = `${slide1Url}&${slide2Url}`;
        findActiveFilter(finalUrl,false,false);
    
    }
    
    setDefaultValue = () => {
        let slides = document.querySelectorAll(".pricerange");
        let slide1 = ( slides[0]);
        let slide2 = ( slides[1]);
        slide1.value = 0;
        slide2.value = slide2.max;
    }   
    
    checkTag = (thisItem) => {
    
        // console.log(thisItem);
        let parent = thisItem.parentElement;
        if(thisItem.checked){
            parent.classList.add("active_tag");
        }
        else {
            parent.classList.remove("active_tag");
        }
    
        let active_content = [];
        let tag_link = '';
        
        // console.log(active_tag);
        let active_tag = document.querySelectorAll('.active_tag');
        if(active_tag.length > 0){
            active_tag.forEach((elem,i)=>{
                
                let tag_content = elem.children[0];
                let tag_link = tag_content.getAttribute('data-link');
                active_content.push(tag_link);
    
            })
    
        }
        tag_link = active_content.join('+');
        findActiveFilter(tag_link,false,true);
    
    }
    
    clickEvent = () => {
        let filter_sm_btn = document.querySelector(".open_btn");
        filter_sm_btn.addEventListener("click",(e) => {
            e.preventDefault();
            openFilterBox();
        })
    
        let filter_sm_close_btn = document.querySelector(".close_btn");
        filter_sm_close_btn.addEventListener("click",() => {
            closeFilterBox();
        })
    }
    
    openFilterBox = () => {
        let filter_box = document.querySelector('.filter-box');
        filter_box.style.left = "0";
    }
    closeFilterBox = () => {
        let filter_box = document.querySelector('.filter-box');
        filter_box.style.left = "-350px";
    }
    
    sortFilterInit = (thisElem) => {
    
        let active_sort_collection = document.querySelectorAll(".active_sort_filter").firstElementChild; 
        let active_sort_link = thisElem.getAttribute('data-value');
        console.log(active_sort_link);
        let sort_url_id = '';
        let sort_all = '/all-category'; 
        let sorturl = document.querySelector('.all_category_section').getAttribute('data-url');
        console.log(sorturl);
        if(window.location.href.indexOf(sort_all) > -1){
            sort_url_id = sorturl + '/' + 'collections/' + active_sort_link;
        }else{
            sort_url_id = sorturl + '/' + 'collections/' + active_sort_link;
        }
    
        console.log(sort_url_id);
    
        window.history.pushState({sort_url_id}, null, sort_url_id);
    
        sortInit(sort_url_id,false);
    }
    
    sortInit = async (sort_url_id,flag) => {
        let url_sort = '';
        if(flag == true){
            url_sort = `${sort_url_id}`;
        }
        else {
            url_sort = `${sort_url_id}?view=filter`;
        }
        // console.log(url);
        // console.log(form_url_id);
        let currentSortFilter = await fetch(url_sort);
        if(currentSortFilter.ok){
            currentSortFilter = await currentSortFilter.text();
            // console.log(currentSortFilter);
            if (document.querySelector(".collection-products")){
                document.querySelector(".collection-products").innerHTML = "";
                let divSortContent = document.createElement("div");
                let sortParser = new DOMParser();
                let filterSortPage = sortParser.parseFromString(currentSortFilter, 'text/html');
                // console.log(filterSortPage);
                filterSortPage = filterSortPage.body.innerHTML;
                divSortContent.innerHTML = filterSortPage;
                // console.log(divSortContent);
                let innerSort = divSortContent.querySelector('.collection-products').innerHTML;
                document.querySelector(".collection-products").innerHTML = innerSort;
                closefilter_loder();
                setSelected();
    
            }
        }
        
        // this.slider();
        changeEvent();
        // this.clickEvent();
        // this.stickyFilter();
        // this.inputEvent();
        // clickEvent();
    }
    
    addFilterUrl = (form_url_id,flag) => {
            // console.log("call");
            let hello_sort_select = document.querySelectorAll("#sort-by");
    
            let add_shopurl = document.querySelector('.all_category_section').getAttribute('data-url');
            let add_collurl = document.querySelector('.category-section-wrap').getAttribute('data-collurl');
            let hello_SortFilters = [];
            let hello_sort_url_id = '';
    
       
            let full_url_link = '';
            if(flag == true){
                full_url_link = `${form_url_id}`;
            }
            else {
                full_url_link = `${form_url_id}?view=filter`;
            }
    
    
            if(hello_sort_select.length > 0){
                hello_sort_select.forEach((item,i)=>{
                    item.addEventListener("change",(e)=>{
                        let that = e.currentTarget;
                        let target = that.value;
                        openfilter_loder();
                        let selected_opt = that.options[that.selectedIndex];
                        // let selected_lenght = that.options.length;
                        let fil_link = document.getElementById('cate_pg').getAttribute('data-filter');
                       
                    
                        for ( let i = 0, len = that.options.length; i < len; i++ ) {
                            opt = that.options[i];
                            if ( opt.selected === true ) {
                                opt.classList.add("active_sort_filter");
                            }
                            else {
                                opt.classList.remove("active_sort_filter");
                            }
                        }   
    
    
                        let hello_active_filters = document.querySelectorAll(".active_sort_filter");
                        if(hello_active_filters.length > 0){
                            hello_active_filters.forEach((elem,i)=>{
                                let hello_filter_link = elem.getAttribute('data-link');
                                // let hello_filter_index = elem.getAttribute('sort_index');
                                // sortFilters = [filter_link];
                                hello_SortFilters= [hello_filter_link]; 
                            })
                        }
                        // console.log("call");
                        if(fil_link != ""){
                            // form_url_id = collurl+ '/?'+ activeFilter.join('&') +'&'+ sortFilters;
                            hello_sort_url_id = add_shopurl + add_collurl +'/?' + fil_link + '&' + hello_SortFilters;
                        }
                        else {
                            hello_sort_url_id = add_shopurl + add_collurl +'/?' + hello_SortFilters;
                        }
                        
                        window.history.pushState({hello_sort_url_id}, null, hello_sort_url_id);
                        let sort_link = document.getElementById('cate_pg');
                        sort_link.getAttributeNode("data-sort").value = hello_SortFilters;
                        // console.log("hello",hello_sort_url_id)
                        sortInit(hello_sort_url_id,true);
                    });
                })
            }
    
            // console.log("adarsh", hello_SortFilters);
            // console.log(add_shopurl);
            // console.log(add_collurl);
    }
    // console.log("adsghj",all_tag_url);
    addFilterUrl();
    
    selectedFilter = () =>{
        selectedValue = [];
    
        if (that.classList.contains('filter-label')) {
            selectedValue = that.getAttribute('data-value');
            console.log("selectedValue",selectedValue)
        } else {
            selectedValue = that.getAttribute('data-value');
            type = that.closest('.product-swatch-wrap')
            if (type) {
                type = type.getAttribute("data-type");
            } else {
                type = that.closest('.size-chart-swatch-wrap.Color').getAttribute("data-type");
            }
        }
    }
    
    setSelected();
    changeEvent();
    clickEvent();
    inputEvent();
    setDefaultValue();
}