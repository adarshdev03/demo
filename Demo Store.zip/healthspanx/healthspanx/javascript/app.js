import scss from "../scss/app.scss"

// require('./compare-product');
require('./lazy-load');
require('./home-page');
require('./product-page');
require('./add-to-cart');
require('./side-cart');
require('./cart-page');
require('./search');
require('./account');
require('./collection-filter');
require('./onscroll_product');
require('./product-swatch');
require('./header');