
if(document.querySelector('body').classList.contains('template-collection')){


productLoader = () => {
    let active_collection = document.querySelector('.collection_url').getAttribute('data-url');
    let limit = document.querySelector('.last_pagination__item').getAttribute('data-value');

// let currunturl = document.querySelector('.pagination__item--prev').getAttribute('data-url');

    collectionURL = '/' + 'collections/' + active_collection + "?page=";

    var products_on_page = $('.collection-products');
    let currentPage = 1
    window.addEventListener('load', () => {
        window.scrollTo(0,0)
    })
    let falg = true;
    window.addEventListener('scroll', () => {
    const {
        scrollTop,
        scrollHeight,
        clientHeight
    } = document.documentElement;
    if (document.getElementById('custom-demo').scrollHeight <  window.scrollY  + 300 ) {
        // console.log("currentPage", collectionURL + currentPage)
        if((parseInt(limit)-1  >= parseInt(currentPage++)) === true) {
            $.ajax(
                    {
                        url:collectionURL+currentPage,
                        type: 'GET',
                        dataType: 'html'
                    }
                ).done(function(next_page) {
                    // console.log("currentPage", collectionURL + currentPage)
                    let url = collectionURL + currentPage ;
                    console.log("urlurl",url)
                    document.querySelector('.add_product_loader').classList.add('active');
                    var new_products = $(next_page).find('.collection-products');
                
                    const myTimeout = setTimeout(myGreeting, 2000);
                    function myGreeting() {
                    products_on_page.append(new_products.html());
                    document.querySelector('.add_product_loader').classList.remove('active');
                    }
                    // closeSideCartLoader();
                } )
        }
        else {
           document.querySelector('.add_product_loader').classList.remove('active');
        }
    }

    }, {
        passive: true
    });
}

productLoader();

}