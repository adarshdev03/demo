import { inToCm, cmToIn ,showPopup, blankBgClose, setCookie, getCookie } from './helper';
class ProductPage{
    constructor(){
        this.storeId = custom.storeId;
        this.customerExist = custom.customerExist;
        this.productId = custom.productId;
        this.productHandle = custom.productHandle;
        this.wishlistUrl = custom.wishlistUrl;
        this.wishlistPageUrl = '/pages/wishlist';
        this.productImgs = custom.productImgs;
        if(this.customerExist){
          this.customerId = custom.customerId;
        }
        this.init();
        // console.log("dsdsd");
    }
    slider = () => {
        
        document.addEventListener( 'DOMContentLoaded', function () {
            $('.img_main_for').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: false,
                dots: false,
                fade: true,
                asNavFor: '.img_main_nav'
            });


            $('.img_main_nav').slick({
            slidesToShow: 5,
            slidesToScroll: 1,
            asNavFor: '.img_main_for',
            dots: false,
            infinite: true,
            arrows: false,
            centerMode: false,
            centerPadding:'0px',
            focusOnSelect: true
            });

            // related product slider
            $('.releated_product_row').slick({
                dots: false,
                infinite: false,
                speed: 300,
                Arrows:true,
                slidesToShow: 4,
                slidesToScroll: 1,
                responsive: [
                {
                    breakpoint: 1025,
                    settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                    }
                },
                {
                    breakpoint: 651,
                    settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                    }
                },
                {
                    breakpoint: 461,
                    settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
                ]
            });

        });
    }

    
    init = () => {
        this.slider();

        if(this.customerExist){
            // If customer is login then fetch data from API
        //   this.findProductExist();
        }else{
          // If customer is not login then fetch data from local storage
        //   this.fetchProductExistLocal();
        }
        // this.reviewBtn();
    }
}
if(document.querySelector('body').classList.contains('template-product')){
    new ProductPage;
}