class AddToCart{
    constructor(){
        // jQuery(".swatch-element").removeClass('active');
        this.init();
    }
    ajaxAddtocart = async (items,flag) => {
        let add = await fetch('/cart/add.js',{
            method:"POST",
            headers: {
                "Content-Type": "application/json"
            },
            body:JSON.stringify({items})
        });
        if(add.ok){
            let stock_err = document.querySelector('.product-action-btn .out-of-stock-err');
            stock_err.style.display = 'none';  
            add = await add.json();
            if(flag){
                let sizeChartEle = document.querySelector('.size-chart-main-wrap');
                if(sizeChartEle && sizeChartEle.classList.contains('show-popup')){
                    sizeChartEle.classList.remove('show-popup');
                }
                sidecartOpen();
            }
        }
        else {
            let stock_err = document.querySelector('.product-action-btn .out-of-stock-err');
            let button = stock_err.previousElementSibling;
            stock_err.style.display = 'block';  
        }
    }
    clickEvent = () => {
        let addBtns = document.querySelectorAll(".add-cart-button");
        if(addBtns.length > 0){
            addBtns.forEach((item,i)=>{
                item.addEventListener("click",(e)=>{
                    let that = e.currentTarget;
                    let id = parseInt(that.getAttribute('data-vid'));
                    let items = [{id:id, quantity:1}];
                    this.ajaxAddtocart(items,true);
                });
            })
        }   

        let productPageAdd = document.querySelectorAll(".product-add-to-cart");
        if(productPageAdd.length > 0){
            productPageAdd.forEach((item,i)=>{
                item.addEventListener("click",(e)=>{
                    // console.log('clicked');
                    let that = e.currentTarget;
                    let qty = parseInt(document.querySelector('.product_qty_num').value);
                    let swatch_elem = document.querySelector(".swatch-element");
                    let variant_err = document.querySelector(".variant_err");
                    let selected_value = document.querySelector(".selected-value");
                    if(that.classList.contains('default_variant')){
                        let vid = parseInt(that.getAttribute('data-id'));
                        // console.log(vid);
                        let items = [];
                        items = [{id:vid, quantity:qty}];
                        this.ajaxAddtocart(items,true);
                        variant_err.style.display = "none";
                    }
                    else{
                        variant_err.style.display = "none";
                        let id = parseInt(document.querySelector('.variants-list').selectedOptions[0].getAttribute('data-id'));
                        if(id != 1){
                            let custimizeEle = document.querySelector('.custimize-size-input');
                            let items = [];
                            if(custimizeEle){
                                let obj = {};
                                let innerParent = document.querySelector('.size-table.in');
                                let custiInput  = innerParent.querySelectorAll('.custimize-size-input input');
                                
                                innerParent.querySelectorAll('thead th').forEach((ele,index)=>{
                                    let objName = ele.textContent;
                                    if(objName != 'Size'){
                                        obj[objName] = custiInput[index - 1].value;
                                    }
                                })
                                items = [{id:id, quantity:qty,properties:obj}];
                            }else{
                                // console.log(custiInput);
                                items = [{id:id, quantity:qty}];
                            }
                            this.ajaxAddtocart(items,true);
                        }else{
                            // jQuery(".swatch-element").removeClass('active');
                            selected_value.innerHTML = "Select Size";
                            swatch_elem.classList.remove('active');
                            variant_err.style.display = "block"
                            // console.log('click');
                        }
                    }
                });
            })
        }
    }
    init = () => {
        this.clickEvent();
    }
}
var addToCartObj = new AddToCart;
export const clickEvent = () =>{
    addToCartObj.clickEvent();
} 