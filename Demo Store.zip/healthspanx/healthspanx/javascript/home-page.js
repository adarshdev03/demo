class HomePage{
  
    constructor(){
        this.init();
    }
    slider = () => {
        // hero slider
        document.addEventListener( 'DOMContentLoaded', function () {
          $('.hero-section-wrap').slick({
            dots: true,
            infinite: true,
            speed: 1000,
            autoplay: true,
            autoplaySpeed: 5000,
            fade: true,
            cssEase: 'linear',
            arrows: true
          });
            // $('.home_product_slider_main').slick({
            //     dots: true,
            //     infinite: false,
            //     speed: 300,
            //     slidesToShow: 2,
            //     dots:false,
            //     arrows: true,
            //     slidesToScroll: 1,
            //     responsive: [
            //       {
            //         breakpoint: 1200,
            //         settings: {
            //           slidesToShow: 2
            //         }
            //       },
            //       {
            //         breakpoint: 992,
            //         settings: {
            //           slidesToShow: 2,
            //         }
            //       },
            //       {
            //         breakpoint: 768,
            //         settings: {
            //           slidesToShow: 2,
            //         }
            //       }
            //       // You can unslick at a given breakpoint now by adding:
            //       // settings: "unslick"
            //       // instead of a settings object
            //     ]
            //   });                    
              $(".slider-collection-row").slick({
                slidesToShow: 3,
                slidesToScroll: 1,
                infinite: false,
                arrows: true,
                dots: false,
                responsive: [
                  {
                    breakpoint: 1200,
                    settings: {
                      slidesToShow: 2,
                      slidesToScroll: 1,
                      dots: false,
                    },
                  },
                  {
                    breakpoint: 992,
                    settings: {
                      arrows: false,
                      slidesToShow: 2,
                      slidesToScroll: 1,
                      dots: true,
                    },
                  },
                  {
                    breakpoint: 551,
                    settings: {
                      slidesToShow: 1,
                      slidesToScroll: 1,
                      dots: true,
                      arrows: false,
                    },
                  },
                ],
              });
              $(".offer_section_wrap").slick({
                slidesToShow: 2,
                slidesToScroll: 1,
                infinite: false,
                dots: true,
                responsive: [
                  {
                    breakpoint: 1200,
                    settings: {
                      slidesToShow: 2,
                      slidesToScroll: 1,
                      dots: true
                    }
                  }, {
                    breakpoint: 992,
                    settings: {
                      arrows: false,
                      centerMode: false,
                      centerPadding: "60px",
                      slidesToShow: 1
                    }
                  }
                ]
              });
              $('.happy_customer_slider').slick({
                arrows:false,
                dots:true,
                slidesToShow: 1,
                slidesToScroll: 1,
                responsive: [
                  {
                    breakpoint: 992,
                    settings: {
                      arrows:false,
                      slidesToShow: 1,
                      slidesToScroll: 1,
                    }
                  }
                ]
              });
              
        });

    }
    init = () => {
        this.slider();
    }
    // menu Button
}

if(document.querySelector('body').classList.contains('template-index')){
    new HomePage;
}


blankBgOpen = () => {
  document.querySelector('.black-bg').classList.add('active');
  document.querySelector('body').classList.add('overflow-hidden');
};

blankBgClose = () => {
document.querySelector('.black-bg').classList.remove('active');
document.querySelector('body').classList.remove('overflow-hidden');
};


var side_bar = document.querySelector('.side_bar');
var openBtn = document.querySelector('#open_btn');
var closeBtn = document.querySelector('#close_btn');

openBtn.addEventListener('click', function () {
  side_bar.style.left = '0px';
  document.querySelector('body').classList.add('overflow-hidden');
  blankBgOpen();
});
closeBtn.addEventListener('click', function () {
  side_bar.style.left = '-100%';
  document.querySelector('body').classList.remove('overflow-hidden');
  blankBgClose ();
});